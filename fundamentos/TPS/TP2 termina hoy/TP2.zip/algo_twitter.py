import funciones as f


def main():
    """ejecuta el programa principal, entrando a cada funcion dependiendo de
    la eleccion del usuario"""

    tweets_existentes = {}
    id = 0
    tokenizados_seg = {}
    while True:
        print()
        ingreso = f.mostrar_inicio()
        if ingreso == f.OPCION_CREAR_TWEET:
            tweets_existentes, id, tokenizados_seg = f.crear_tweet(
                tweets_existentes, id, tokenizados_seg
            )
        elif ingreso == f.OPCION_BUSCAR_TWEET:
            f.buscar_tweet(tweets_existentes, tokenizados_seg)
        elif ingreso == f.OPCION_ELIMINAR_TWEET:
            f.eliminar_tweet(tweets_existentes, tokenizados_seg)
        elif ingreso == f.OPCION_SALIR:
            print(f.FIN)
            break
        else:
            print(f.INPUT_INVALIDO)


if __name__ == "__main__":
    main()
